﻿namespace Search.Base
{
    public enum NodeVisitAction
    {
        PreVisit,
        Visit,
        PostVisit,
        FoundResult,
        Reset,
        LogAction
    }
}