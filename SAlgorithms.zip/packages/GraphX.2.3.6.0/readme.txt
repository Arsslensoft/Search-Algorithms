﻿
Hey you there! Yes, you!
 
We want to thank you for using GraphX for.NET and give you an exclusive
promo code for our newest GraphX for .NET PRO! It is better, faster, optimized for
big data graphs and includes new cool graph layout algorithms for you to play!

Find out more and get it at http://www.graphx.pro

Oh yes, the code is GRAPHXPRO1608D10 and is valid only until the 09/18/2016!
Just send it to us when you’re ready for the purchase and get special discount!

Hurry up!


GraphX for .NET (open-source) version resources:

 * Documentation: https://github.com/panthernet/GraphX/wiki
 * Sample code:   https://github.com/panthernet/GraphX/tree/PCL/Examples
 * Tutorials:     http://panthernet.ru/forum/index.php/forum/16-documents-tutorials/
 * Devs forum:    http://panthernet.ru/forum
 
 Feel free to ask your questions on the forum or send us an e-mail to support@panthernet.org